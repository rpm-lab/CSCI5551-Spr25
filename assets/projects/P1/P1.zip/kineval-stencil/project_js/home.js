home = {}; 


home.define_array = function define_array() {
    
}

home.sort_array = function sort_array(input) {

}

home.define_global = function define_global() {

}

home.define_object = function define_object() {
    
}

home.debug_secret = function debug_secret() {

}
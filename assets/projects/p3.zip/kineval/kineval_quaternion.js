//////////////////////////////////////////////////
/////     QUATERNION TRANSFORM ROUTINES 
//////////////////////////////////////////////////

// STENCIL: reference quaternion code has the following functions:
//   quaternion_from_axisangle
//   quaternion_normalize
//   quaternion_to_rotation_matrix
//   quaternion_multiply



// **** Function stencils are provided below, please uncomment and implement them ****//


/**
 * Computes a quaternion from axis and angle
 * 
 * @param {number[]} axis - The axis of rotation (should be len 3).
 * @param {number} angle - The angle.
 * 
 * @returns {{a: number, b: number, c: number, d: number}} The quaternion.
 */
// kineval.quaternionFromAxisAngle = function quaternion_from_axisangle(axis,angle) {
//     // returns quaternion q as dic, with q.a as real number, q.b as i component, q.c as j component, q.d as k component
//     var q = {};

// }

/**
 * Normalizes a quaternion
 * 
 * @param {{a: number, b: number, c: number, d: number}} q1 - a quaternion.
 * 
 * @returns {{a: number, b: number, c: number, d: number}} The normalized quaternion
 */
// kineval.quaternionNormalize = function quaternion_normalize(q1) {
//     // returns quaternion q as dic, with q.a as real number, q.b as i component, q.c as j component, q.d as k component
//     var q = {};

// }

/**
 * 
 * @param {{a: number, b: number, c: number, d: number}} q1 - a quaternion.
 * @param {{a: number, b: number, c: number, d: number}} q2 - another quaternion.
 * 
 * @returns {{a: number, b: number, c: number, d: number}} The product of the two quaternions.
 */
// kineval.quaternionMultiply = function quaternion_multiply(q1,q2) {
//     // returns quaternion q as dic, with q.a as real number, q.b as i component, q.c as j component, q.d as k component
//     var q = {};
    

// }

/**
 * 
 * @param {{a: number, b: number, c: number, d: number}} q - a quaternion.
 * 
 * @returns {number[][]} The 4x4 rotation matrix.
 */
// kineval.quaternionToRotationMatrix = function quaternion_to_rotation_matrix (q) {
//     // returns 4-by-4 2D rotation matrix

// }
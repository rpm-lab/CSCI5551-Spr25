//////////////////////////////////////////////////
/////     MATRIX ALGEBRA AND GEOMETRIC TRANSFORMS 
//////////////////////////////////////////////////

function matrix_copy(m1) {
    // returns 2D array that is a copy of m1

    var mat = [];
    var i,j;

    for (i=0;i<m1.length;i++) { // for each row of m1
        mat[i] = [];
        for (j=0;j<m1[0].length;j++) { // for each column of m1
            mat[i][j] = m1[i][j];
        }
    }
    return mat;
}


// STENCIL: reference matrix code has the following functions:
//   matrix_multiply
//   matrix_transpose
//   matrix_pseudoinverse
//   matrix_invert_affine
//   vector_normalize
//   vector_cross
//   generate_identity
//   generate_translation_matrix
//   generate_rotation_matrix_X
//   generate_rotation_matrix_Y
//   generate_rotation_matrix_Z



// **** Function stencils are provided below, please uncomment and implement them ****//



/**
 * returns 2D array that is the result of the matrix multiplication m1*m2
 * 
 * @param {number[][]} m1 - The first matrix to multiply
 * @param {number[][]} m2 - The second matrix to multiply
 * @returns {number[][]} - The result of the matrix multiplication
 */
function matrix_multiply(m1, m2) {
    /**
     * you should make a NEW 2D array to store the result of the matrix multiplication
     * 
     * This is a stencil for project 2 CSCI 5551
     */

    // TODO: YOUR CODE HERE



}


/**
 * Matrix transpose function
 * 
 * 
 * @param {number[][]} m - a matrix to transpose
 * @returns {number[][]} - The transpose of the input matrix
 */
function matrix_transpose(m) {
    /**
     * Here you should implement the matrix transpose function
     * 
     * The transpose of a matrix is a new matrix whose rows are the columns of the original.
     * A[i][j] of the original matrix becomes A[j][i] in the transposed matrix
     * 
     * This is a stencil for project 2 CSCI 5551
     * 
     */

    // TODO: YOUR CODE HERE



}




/**
 * Calculates and returns the pseudoinverse of a matrix
 * 
 * UNCOMMENT THIS FUNCTION IF YOU ARE IMPLEMENTING IT
 * 
 * @param {number[][]} m - an input matrix
 * @returns {number[][]} - The pseudoinverse of the input matrix
 */
// function matrix_pseudoinverse(m) {
    /**
     * Here you should implement the calculation of the pseudoinverse of the matrix m
     * 
     * This function is NOT required for project 2 CSCI 5551. Motivated students are encouraged to implement it.
     * 
     */




// }



/**
 * Calculates and returns the invert affine of a 4-by-4 matrix
 * 
 * UNCOMMENT THIS FUNCTION IF YOU ARE IMPLEMENTING IT
 * 
 * @param {number[][]} m - an input matrix
 * @returns {number[][]} - The invert affine of 4-by-4 matrix m
 */
// function matrix_invert_affine(m) {
    /**
     * Here you should implement the invert affine of a 4-by-4 matrix
     * 
     * 
     * This function is NOT required for project 2 CSCI 5551. Motivated students are encouraged to implement it.
     * 
     */

// }

/**
 * Normalizes a vector v
 * 
 * @param {number[]} v - The input vector
 * @returns {number[]} 
 */
function vector_normalize(v) {
    /**
     * Here you should implement the normalization of a vector
     * 
     * Formula: v_normalized = v / |v|
     * 
     * This is a stencil for project 2 CSCI 5551
     */

    // TODO: YOUR CODE HERE

    
}

/**
 * Calculates the cross product of two vectors
 * 
 * @param {number[]} a 
 * @param {number[]} b 
 */
function vector_cross(a,b) {
    /**
     * Here you should implement the cross product of two vectors
     * 
     * This is a stencil for project 2 CSCI 5551
     */

    // TODO: YOUR CODE HERE


    
}

/**
 * Generates an identity matrix
 * 
 * @param {number} n - The size of the identity matrix
 * 
 */
function generate_identity(n=4) {
    /**
     * Here you should implement the generation of an identity matrix
     * 
     * This is a stencil for project 2 CSCI 5551
     */

    // TODO: YOUR CODE HERE

    

}

/**
 * Generates a translation matrix(4x4) for the given translation values
 * 
 * @param {number} tx - The translation value in x-axis
 * @param {number} ty - The translation value in y-axis
 * @param {number} tz - The translation value in z-axis
 */
function generate_translation_matrix(tx, ty, tz) {
    /**
     * Here you should implement the generation of a translation matrix
     * 
     * This is a stencil for project 2 CSCI 5551
     */

    // TODO: YOUR CODE HERE


    
    
}

/**
 * Generates a rotation matrix around the x-axis
 * 
 * @param {number} angle - The angle of rotation in radians
 */
function generate_rotation_matrix_X(angle) {
    /**
     * Here you should implement the generation of a rotation matrix around the x-axis
     * 
     * This is a stencil for project 2 CSCI 5551
     */

    // TODO YOUR CODE HERE

    
    
}


/**
 * Generates a rotation matrix around the y-axis
 * 
 * @param {number} angle - The angle of rotation in radians
 */
function generate_rotation_matrix_Y(angle) {
    /**
     * Here you should implement the generation of a rotation matrix around the y-axis
     * 
     * This is a stencil for project 2 CSCI 5551
     */

    // TODO: YOUR CODE HERE

    
    
}

/**
 * Generates a rotation matrix around the z-axis
 * 
 * @param {number} angle - The angle of rotation in radians
 */
function generate_rotation_matrix_Z(angle) {
    /**
     * Here you should implement the generation of a rotation matrix around the z-axis
     * 
     * This is a stencil for project 2 CSCI 5551
     */

    // TODO: YOUR CODE HERE

    


    
}
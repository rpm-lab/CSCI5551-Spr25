/*-- |\/| |\/| |\/| |\/| |\/| |\/| |\/| |\/| |\/| |\/| |\/| |\/| |\/| |\/| |\/|

    KinEval | Kinematic Evaluator | forward kinematics

    Implementation of robot kinematics, control, decision making, and dynamics 
        in HTML5/JavaScript and threejs
     
    @author ohseejay / https://github.com/ohseejay / https://bitbucket.org/ohseejay

    Chad Jenkins
    Laboratory for Perception RObotics and Grounded REasoning Systems
    University of Michigan

     Updated and modified by coursestaff Adit Kadepurkar, Xun Tu, Mohit Yadav, Karthik Desingh of CSCI 5551 Spring Term - https://rpm-lab.github.io/CSCI5551-Spr25/
     Robotics: Perception and Manipulation Lab
     University of Minnesota

    License: Creative Commons 3.0 BY-SA

|\/| |\/| |\/| |\/| |\/| |\/| |\/| |\/| |\/| |\/| |\/| |\/| |\/| |\/| |\/| --*/



///////////////////////////////////////////////////////

// Important API guide for the robot object and subobjects(may not be exhaustive):

/**
 * @typedef {Object} Robot
 * @property {string} name - The name of the robot.
 * @property {Object} origin - The initial pose of the robot in the world.
 * @property {number[]} origin.xyz - The position of the robot in the world (x, y, z).
 * @property {number[]} origin.rpy - The orientation of the robot in the world (roll, pitch, yaw).
 * @property {string} base - The base link of the robot.
 * @property {Object.<string, Object>} links - The links of the robot.
 * @property {Object.<string, Joint>} joints - The joints of the robot.
 * @property {EndEffector} endeffector - The end effector of the robot.
 */

/**
 * @typedef {Object} Joint
 * @property {string} parent - The parent (inboard) link of the joint.
 * @property {string} child - The child (outboard) link of the joint.
 * @property {string[]} children - The children joints of the joint.
 * @property {Object} origin - The origin of the joint relative to the parent link.
 * @property {number[]} origin.xyz - The position of the joint relative to the parent link (x, y, z).
 * @property {number[]} origin.rpy - The orientation of the joint relative to the parent link (roll, pitch, yaw).
 * @property {number[]} axis - The axis of rotation for the joint.
 * @property {number} angle - The angle of the joint.
 * @property {number} control - The control input for the joint.
 * 
 * @property {Object} servo - The servo control parameters for the joint.
 * @property {number} servo.p_gain - The proportional gain of the servo control.
 * @property {number} servo.p_desired - The desired position of the servo control.
 * @property {number} servo.d_gain - The derivative gain of the servo control.
 * 
 */

/**
 * @typedef {Object} EndEffector
 * @property {string} frame - The frame of the end effector.
 * @property {number[][]} position - The position of the end effector.
 */

///////////////////////////////////////////////////////


/**
 * Computes the forward kinematics for the robot.
 * 
 * This function checks if the `buildFKTransforms` function is defined. If not, it updates the text bar to indicate that forward kinematics is not implemented and returns.
 * Otherwise, it proceeds to implement the forward kinematics by calling the `buildFKTransforms` function.
 */
kineval.robotForwardKinematics = function robotForwardKinematics () { 

    if (typeof kineval.buildFKTransforms === 'undefined') {
        textbar.innerHTML = "forward kinematics not implemented";
        return;
    }

    kineval.buildFKTransforms();

}

// STENCIL: PLEASE READ
// 
//   reference code alternates recursive traversal over 
//   links and joints starting from base, by implementing the
//   following functions: 
//     traverseFKBase
//     traverseFKLink
//     traverseFKJoint
//
// user interface needs the heading (z-axis) and lateral (x-axis) directions
//   of robot base in world coordinates stored as 4x1 matrices in
//   global variables "robot_heading" and "robot_lateral"
//
// if geometries are imported and using ROS coordinates (e.g., fetch),
//   coordinate conversion is needed for kineval/threejs coordinates:
//


// TODO UNCOMMENT THESE THREE LINES
// kineval.buildFKTransforms = function buildFKTransforms() {
//     kineval.traverseFKBase(); // nothing to be done here
// }


var robot_heading;
var robot_lateral;

/**
 * Traverses the base of the robot to compute its transformation matrix.
 * 
 * This function initializes the transformation matrix for the robot's base using its origin's position and orientation.
 * It also computes the robot's heading and lateral directions in world coordinates.
 * If the robot's geometries are imported and using ROS coordinates, it performs a coordinate conversion.
 * Finally, it calls `traverseFKLink` to continue the traversal from the base link.
 */
kineval.traverseFKBase = function traverseFKBase() {
    // TODO: YOUR CODE HERE

    

}

/**
 * Traverses a link of the robot to compute its transformation matrix.
 * 
 * @param {string} linkname - The name of the link to traverse.
 * @param {Array} parent_xform - The transformation matrix of the parent link or joint.
 * 
 * This function sets the transformation matrix for the specified link and recursively traverses its child joints.
 */
kineval.traverseFKLink = function traverseFKLink(linkname, parent_xform) {
    // TODO: YOUR CODE HERE


}


/**
 * Traverses a joint of the robot to compute its transformation matrix.
 * 
 * @param {string} joint_name - The name of the joint to traverse.
 * @param {Array} parent_xform - The transformation matrix of the parent link or joint.
 * 
 * This function computes the local transformation matrix, finds the joint_xform, 
 * and recursively traverses its child link.
 * 
 * 
 */
kineval.traverseFKJoint = function traverseFKJoint(joint_name, parent_xform) {
    // TODO: YOUR CODE HERE






}

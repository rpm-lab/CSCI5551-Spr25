/*|\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\
|\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/|
||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/
/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\

    2D Path Planning in HTML5 Canvas | Graph Search Methods

    Stencil methods for student implementation of graph search algorithms.

    @author ohseejay / https://github.com/ohseejay
                     / https://bitbucket.org/ohseejay

    Chad Jenkins
    Laboratory for Perception RObotics and Grounded REasoning Systems
    University of Michigan

    License: Michigan Honor License

    Usage: see search_canvas.html

|\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/|
||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/
/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\
\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/||\/*/

function initSearchGraph() {

    // create the search queue
    visit_queue = [];

    // initialize search graph as 2D array over configuration space
    //   of 2D locations with specified spatial resolution
    G = [];
    for (iind=0,xpos=-2;xpos<7;iind++,xpos+=eps) {
        G[iind] = [];
        for (jind=0,ypos=-2;ypos<7;jind++,ypos+=eps) {
            G[iind][jind] = {
                i:iind,j:jind, // mapping to graph array
                x:xpos,y:ypos, // mapping to map coordinates
                parent:null, // pointer to parent in graph along motion path
                distance:10000, // distance to start via path through parent
                visited:false, // flag for whether the node has been visited
                priority:null, // visit priority based on fscore
                queued:false // flag for whether the node has been queued for visiting
            };

            // STENCIL: determine whether this graph node should be the start
            //   point for the search
            if (Math.abs(xpos - q_init[0]) < 0.00001 && Math.abs(ypos - q_init[1]) < 0.00001) {
                G[iind][jind].distance = 0;
                G[iind][jind].priority = 0;
                G[iind][jind].queued = true;
                visit_queue.push(G[iind][jind]);
            }
        }
    }
}

function iterateGraphSearch() {


    // STENCIL: implement a single iteration of a graph search algorithm
    //   for A-star (or DFS, BFS, Greedy Best-First)
    //   An asynch timing mechanism is used instead of a for loop to avoid
    //   blocking and non-responsiveness in the browser.
    //
    //   Return "failed" if the search fails on this iteration.
    //   Return "succeeded" if the search succeeds on this iteration.
    //   Return "iterating" otherwise.
    //
    //   Provided support functions:
    //
    //   testCollision - returns whether a given configuration is in collision
    //   drawHighlightedPathGraph - draws a path back to the start location
    //   draw_2D_configuration - draws a square at a given location

    if (search_alg == "depth-first") {
        cur_node = visit_queue.pop();
    } else if (search_alg == 'breadth-first') {
        cur_node = visit_queue.shift();
    } else {
        return "failed";
    }
    cur_node.queued = false;
    cur_node.visited = true;
    draw_2D_configuration([cur_node.x, cur_node.y], 'visited');

    // console.log(cur_node.i, cur_node.j);

    offsets = [
        [1, 0],
        [-1, 0],
        [0, 1],
        [0, -1],
    ];
    for (offset of offsets) {
        iind = cur_node.i + offset[0]
        jind = cur_node.j + offset[1]
        if (iind < 0 || iind >= G.length || jind < 0 || jind >= G[0].length) {
            continue;
        }
        if (G[iind][jind].visited || G[iind][jind].queued || testCollision([G[iind][jind].x, G[iind][jind].y])) {
            continue;
        }
        G[iind][jind].parent = cur_node;
        G[iind][jind].distance = cur_node.distance + eps;
        G[iind][jind].queued = true;
        visit_queue.push(G[iind][jind]);
        draw_2D_configuration([G[iind][jind].x, G[iind][jind].y], 'queued');
    }
    if (Math.abs(cur_node.x - q_goal[0]) < 0.00001 && Math.abs(cur_node.y - q_goal[1]) < 0.00001) {
        drawHighlightedPathGraph(cur_node);
        search_iterate = false;
        return "succeeded";
    } else {
        return "iterating";
    }
}

//////////////////////////////////////////////////
/////     MIN HEAP IMPLEMENTATION FUNCTIONS
//////////////////////////////////////////////////

    // STENCIL: implement min heap functions for graph search priority queue.
    //   These functions work use the 'priority' field for elements in graph.
